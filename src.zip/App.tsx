import { useMemo, useState } from "react";

type Platform = "Instagram" | "TikTok" | "YouTube" | "Facebook" | "Threads";
type Service = {
  platform: Platform;
  title: string;
  description: string;
  price: number;
  unit: string;
  accent: string;
  mark: string;
  popular?: boolean;
};

const services: Service[] = [
  {
    platform: "Instagram",
    title: "Бодит дагагч",
    description: "Тогтвортой үлдэх, чанартай дагагчийг жигд хурдаар нэмнэ.",
    price: 10000,
    unit: "1,000 дагагч",
    accent: "bg-[#ff5d8f]",
    mark: "IG",
    popular: true,
  },
  {
    platform: "TikTok",
    title: "Бодит дагагч",
    description: "TikTok профайлын хүрэлт, итгэлцлийг чанартай дагагчаар өсгөнө.",
    price: 10000,
    unit: "1,000 дагагч",
    accent: "bg-[#6fffe9]",
    mark: "TT",
  },
  {
    platform: "YouTube",
    title: "Сувгийн захиалагч",
    description: "Сувгийн нэр хүндийг тогтвортой захиалагчдаар нэмэгдүүлнэ.",
    price: 20000,
    unit: "1,000 захиалагч",
    accent: "bg-[#ff4d3d]",
    mark: "YT",
  },
  {
    platform: "Facebook",
    title: "Пэйжийн лайк",
    description: "Чанартай профайлаас пэйжийн итгэлцэл, оролцоог нэмэгдүүлнэ.",
    price: 5000,
    unit: "1,000 лайк",
    accent: "bg-[#4385ff]",
    mark: "FB",
  },
  {
    platform: "Threads",
    title: "Постын түгээлт",
    description: "Таны нийтлэлийг илүү өргөн хүрээнд түгээж, яриа өрнүүлнэ.",
    price: 4000,
    unit: "1,000 түгээлт",
    accent: "bg-[#d8ff3e]",
    mark: "TH",
  },
  {
    platform: "Instagram",
    title: "Постын лайк",
    description: "Постын органик харагдах байдал, оролцоог эрчимжүүлнэ.",
    price: 5000,
    unit: "1,000 лайк",
    accent: "bg-[#b876ff]",
    mark: "IG",
  },
];

const platforms: Array<"All" | Platform> = [
  "All",
  "Instagram",
  "TikTok",
  "YouTube",
  "Facebook",
  "Threads",
];

const platformLabels: Record<(typeof platforms)[number], string> = {
  All: "Бүгд",
  Instagram: "Instagram",
  TikTok: "TikTok",
  YouTube: "YouTube",
  Facebook: "Facebook",
  Threads: "Threads",
};

type ServiceKind = "followers" | "likes" | "shares" | "subscribers";

const calculatorServices: Array<{
  id: ServiceKind;
  label: string;
  singular: string;
  price: number;
}> = [
  { id: "followers", label: "Followers", singular: "дагагч", price: 10 },
  { id: "likes", label: "Likes", singular: "лайк", price: 5 },
  { id: "shares", label: "Share", singular: "шэйр", price: 4 },
  { id: "subscribers", label: "Subscribe", singular: "захиалагч", price: 20 },
];

const platformStyles: Record<Platform, { mark: string; accent: string }> = {
  Instagram: { mark: "IG", accent: "bg-[#ff5d8f]" },
  TikTok: { mark: "TT", accent: "bg-[#6fffe9]" },
  YouTube: { mark: "YT", accent: "bg-[#ff4d3d]" },
  Facebook: { mark: "FB", accent: "bg-[#4385ff]" },
  Threads: { mark: "TH", accent: "bg-[#d8ff3e]" },
};

const formatMnt = (value: number) =>
  new Intl.NumberFormat("mn-MN", { maximumFractionDigits: 0 }).format(value) + "₮";

function Arrow({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M4 10h11M10.5 5.5 15 10l-4.5 4.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function Check() {
  return (
    <svg className="size-4" viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <path d="m3 8 3.1 3L13 4.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function Star() {
  return (
    <svg className="size-4 fill-current" viewBox="0 0 20 20" aria-hidden="true">
      <path d="m10 1.8 2.5 5.1 5.6.8-4 3.9.9 5.6-5-2.6-5 2.6.9-5.6-4-3.9 5.6-.8L10 1.8Z" />
    </svg>
  );
}

function ServiceCard({
  service,
  onSelect,
}: {
  service: Service;
  onSelect: (service: Service) => void;
}) {
  return (
    <article className="group relative flex min-h-80 flex-col justify-between overflow-hidden rounded-[1.75rem] border border-black/10 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:shadow-[0_20px_50px_rgba(17,17,17,0.12)]">
      {service.popular && (
        <span className="absolute right-5 top-5 rounded-full bg-[#d8ff3e] px-3 py-1 text-[10px] font-black uppercase tracking-[0.14em]">
          Хамгийн эрэлттэй
        </span>
      )}
      <div>
        <div className={`grid size-12 place-items-center rounded-2xl ${service.accent} text-sm font-black tracking-tight text-[#111111]`}>
          {service.mark}
        </div>
        <p className="mt-6 text-xs font-bold uppercase tracking-[0.16em] text-black/45">{platformLabels[service.platform]}</p>
        <h3 className="mt-2 text-2xl font-bold tracking-[-0.04em]">{service.title}</h3>
        <p className="mt-3 max-w-64 text-sm leading-6 text-black/55">{service.description}</p>
      </div>
      <div className="mt-8 flex items-end justify-between border-t border-black/10 pt-5">
        <div>
          <p className="text-xs text-black/45">Эхлэх үнэ</p>
          <p className="mt-1 text-2xl font-bold tracking-tight">
            {formatMnt(service.price)}
            <span className="ml-1 text-xs font-medium text-black/40">/ {service.unit}</span>
          </p>
        </div>
        <button
          onClick={() => onSelect(service)}
          className="grid size-11 cursor-pointer place-items-center rounded-full bg-[#111111] text-white transition group-hover:rotate-[-10deg] group-hover:bg-[#6d4aff] focus:outline-none focus:ring-4 focus:ring-[#6d4aff]/20"
          aria-label={`${service.platform} ${service.title} сонгох`}
        >
          <Arrow className="size-5" />
        </button>
      </div>
    </article>
  );
}

function GrowthCalculator({ onOrder }: { onOrder: (service: Service) => void }) {
  const [platform, setPlatform] = useState<Platform>("Instagram");
  const [serviceKind, setServiceKind] = useState<ServiceKind>("followers");
  const [amount, setAmount] = useState(5000);
  const [trackingCode, setTrackingCode] = useState("");
  const [trackingMessage, setTrackingMessage] = useState("");
  const selectedService = calculatorServices.find((service) => service.id === serviceKind) ?? calculatorServices[0];
  const total = selectedService.price * amount;
  const platformStyle = platformStyles[platform];

  const trackOrder = () => {
    setTrackingMessage(
      trackingCode.trim()
        ? `Захиалга ${trackingCode.trim().toUpperCase()} — хүргэлтийн мэдээллийг шалгаж байна.`
        : "Захиалгын дугаараа оруулна уу.",
    );
  };

  const choosePlatform = (nextPlatform: Platform) => {
    setPlatform(nextPlatform);
    if (nextPlatform !== "YouTube" && serviceKind === "subscribers") setServiceKind("followers");
  };

  const chooseService = (nextService: ServiceKind) => {
    setServiceKind(nextService);
    if (nextService === "subscribers") setPlatform("YouTube");
  };

  return (
    <section className="relative z-20 mx-auto -mb-12 max-w-[1312px] px-5 md:-mb-16 md:px-10 lg:px-16">
      <div className="grid overflow-hidden rounded-[2rem] border border-black/10 bg-white shadow-[0_24px_70px_rgba(17,17,17,0.13)] lg:grid-cols-[1.35fr_0.65fr]">
        <div className="p-6 md:p-9">
          <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.16em] text-[#6d4aff]">Шууд үнэ бодох</p>
              <h2 className="mt-2 text-2xl font-black tracking-[-0.04em] md:text-3xl">Үйлчилгээгээ сонгоод үнээ мэдээрэй</h2>
            </div>
            <span className="w-fit rounded-full bg-[#d8ff3e] px-3 py-1.5 text-xs font-bold">Нууц үг шаардахгүй</span>
          </div>

          <div className="mt-7">
            <p className="text-xs font-bold text-black/50">1. Платформ</p>
            <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-5">
              {platforms.slice(1).map((item) => (
                <button
                  key={item}
                  onClick={() => choosePlatform(item as Platform)}
                  className={`cursor-pointer rounded-xl border px-3 py-3 text-xs font-black transition ${
                    platform === item
                      ? "border-[#6d4aff] bg-[#6d4aff] text-white shadow-lg shadow-[#6d4aff]/15"
                      : "border-black/10 bg-[#f5f3ee] text-black/55 hover:border-black/25"
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-6">
            <p className="text-xs font-bold text-black/50">2. Үйлчилгээ</p>
            <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {calculatorServices.map((service) => (
                <button
                  key={service.id}
                  onClick={() => chooseService(service.id)}
                  className={`relative cursor-pointer rounded-xl border px-3 py-3 text-left transition ${
                    serviceKind === service.id
                      ? "border-[#111111] bg-[#111111] text-white"
                      : "border-black/10 bg-white hover:border-black/30"
                  }`}
                >
                  <span className="block text-sm font-black">{service.label}</span>
                  <span className={`mt-1 block text-[10px] ${serviceKind === service.id ? "text-[#d8ff3e]" : "text-black/40"}`}>
                    1 {service.singular} = {formatMnt(service.price)}
                  </span>
                  {service.id === "subscribers" && <span className="absolute right-2 top-2 size-1.5 rounded-full bg-[#ff4d3d]" />}
                </button>
              ))}
            </div>
            {serviceKind === "subscribers" && <p className="mt-2 text-[10px] font-semibold text-black/40">Subscribe үйлчилгээ YouTube сувагт зориулагдсан.</p>}
          </div>

          <div className="mt-6">
            <label className="block">
              <span className="flex justify-between text-xs font-bold text-black/50">
                <span>3. Тоо хэмжээ</span>
                <strong className="text-[#6d4aff]">{new Intl.NumberFormat("mn-MN").format(amount)} {selectedService.singular}</strong>
              </span>
              <input
                type="range"
                min="100"
                max="50000"
                step="100"
                value={amount}
                onChange={(event) => setAmount(Number(event.target.value))}
                className="mt-5 w-full cursor-pointer accent-[#6d4aff]"
                aria-label="Үйлчилгээний тоо хэмжээ"
              />
              <span className="mt-1 flex justify-between text-[10px] font-semibold text-black/35"><span>100</span><span>50,000</span></span>
            </label>
          </div>
        </div>

        <div className="flex flex-col justify-between bg-[#6d4aff] p-6 text-white md:p-9">
          <div>
            <div className="mb-10 flex items-center gap-3">
              <span className={`grid size-11 place-items-center rounded-xl ${platformStyle.accent} text-xs font-black text-black`}>{platformStyle.mark}</span>
              <div>
                <p className="text-sm font-black">{platform}</p>
                <p className="text-xs text-white/50">{selectedService.label}</p>
              </div>
            </div>
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-white/55">Таны нийт үнэ</p>
            <p className="mt-3 text-4xl font-black tracking-[-0.05em] md:text-5xl">{formatMnt(total)}</p>
            <p className="mt-2 text-xs text-white/55">{new Intl.NumberFormat("mn-MN").format(amount)} × {formatMnt(selectedService.price)}</p>
          </div>
          <button
            onClick={() => onOrder({
              platform,
              title: selectedService.label,
              description: `${platform} дээрх ${selectedService.singular} нэмэх үйлчилгээ.`,
              price: total,
              unit: `${new Intl.NumberFormat("mn-MN").format(amount)} ${selectedService.singular}`,
              accent: platformStyle.accent,
              mark: platformStyle.mark,
            })}
            className="group mt-7 flex w-full cursor-pointer items-center justify-center gap-2 rounded-full bg-[#d8ff3e] px-6 py-4 font-black text-black transition hover:scale-[1.02]"
          >
            Одоо захиалах <Arrow className="size-5 transition-transform group-hover:translate-x-1" />
          </button>
        </div>
      </div>

      <div className="mx-auto flex max-w-2xl translate-y-4 flex-col gap-3 rounded-2xl border border-black/10 bg-[#111111] p-3 text-white shadow-xl sm:flex-row sm:items-center">
        <div className="px-3">
          <p className="text-xs font-black">Захиалга хянах</p>
          <p className="text-[10px] text-white/45">Хүргэлтийн явцаа шалгаарай</p>
        </div>
        <div className="flex min-w-0 flex-1 gap-2">
          <input
            value={trackingCode}
            onChange={(event) => { setTrackingCode(event.target.value); setTrackingMessage(""); }}
            onKeyDown={(event) => event.key === "Enter" && trackOrder()}
            placeholder="Жишээ: SM-2048"
            className="min-w-0 flex-1 rounded-xl border border-white/10 bg-white/10 px-4 py-3 text-sm outline-none placeholder:text-white/30 focus:border-[#d8ff3e]"
          />
          <button onClick={trackOrder} className="shrink-0 cursor-pointer rounded-xl bg-white px-4 py-3 text-xs font-black text-black transition hover:bg-[#d8ff3e]">Шалгах</button>
        </div>
      </div>
      {trackingMessage && <p className="mx-auto mt-6 max-w-2xl text-center text-xs font-bold text-black/60">{trackingMessage}</p>}
    </section>
  );
}

export default function App() {
  const [activePlatform, setActivePlatform] = useState<(typeof platforms)[number]>("All");
  const [selected, setSelected] = useState<Service | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [targetAccount, setTargetAccount] = useState("");
  const [checkoutStep, setCheckoutStep] = useState<"account" | "payment">("account");
  const [paymentCode, setPaymentCode] = useState("");
  const [copied, setCopied] = useState("");

  const visibleServices = useMemo(
    () => services.filter((service) => activePlatform === "All" || service.platform === activePlatform),
    [activePlatform],
  );

  const scrollToServices = () => {
    document.getElementById("services")?.scrollIntoView({ behavior: "smooth" });
  };

  const closeCheckout = () => {
    setSelected(null);
    setTargetAccount("");
    setCheckoutStep("account");
    setPaymentCode("");
    setCopied("");
  };

  const openPayment = () => {
    if (!targetAccount.trim()) return;
    setPaymentCode(String(Math.floor(10000 + Math.random() * 90000)));
    setCheckoutStep("payment");
  };

  const copyPaymentValue = async (value: string, label: string) => {
    await navigator.clipboard.writeText(value);
    setCopied(label);
    window.setTimeout(() => setCopied(""), 1600);
  };

  return (
    <div className="min-h-screen overflow-hidden bg-[#f5f3ee] text-[#111111]">
      <div className="bg-[#d8ff3e] px-4 py-2.5 text-center text-xs font-black uppercase tracking-[0.08em]">
        1 Instagram дагагч ердөө <span className="rounded bg-black px-2 py-1 text-white">10₮</span> · Нууц үг шаардахгүй
      </div>
      <header className="relative z-40 mx-auto flex max-w-[1440px] items-center justify-between px-5 py-5 md:px-10 lg:px-16">
        <a href="#" className="flex items-center gap-2.5" aria-label="DAGALTSAY нүүр">
          <span className="grid size-9 rotate-[-8deg] place-items-center rounded-xl bg-[#111111] text-sm font-black text-[#d8ff3e]">D</span>
          <span className="text-lg font-black tracking-[-0.05em]">DAGALTSAY</span>
        </a>

        <nav className="hidden items-center gap-8 text-sm font-semibold md:flex" aria-label="Үндсэн цэс">
          <button onClick={scrollToServices} className="cursor-pointer transition hover:text-[#6d4aff]">Үйлчилгээ</button>
          <a href="#how-it-works" className="transition hover:text-[#6d4aff]">Хэрхэн ажиллах вэ?</a>
          <a href="#reviews" className="transition hover:text-[#6d4aff]">Сэтгэгдэл</a>
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <button className="cursor-pointer rounded-full px-4 py-2.5 text-sm font-bold transition hover:bg-black/5">Нэвтрэх</button>
          <button onClick={scrollToServices} className="cursor-pointer rounded-full bg-[#111111] px-5 py-3 text-sm font-bold text-white transition hover:-translate-y-0.5 hover:bg-[#6d4aff]">
            Эхлэх
          </button>
        </div>
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="grid size-11 cursor-pointer place-items-center rounded-full border border-black/15 md:hidden"
          aria-label="Цэс нээх, хаах"
          aria-expanded={menuOpen}
        >
          <span className="space-y-1.5">
            <span className="block h-0.5 w-5 bg-black" />
            <span className="block h-0.5 w-5 bg-black" />
          </span>
        </button>
        {menuOpen && (
          <div className="absolute left-5 right-5 top-20 rounded-3xl bg-[#111111] p-6 text-white shadow-2xl md:hidden">
            <nav className="flex flex-col gap-5 text-lg font-bold">
              <button onClick={() => { scrollToServices(); setMenuOpen(false); }} className="text-left">Үйлчилгээ</button>
              <a href="#how-it-works" onClick={() => setMenuOpen(false)}>Хэрхэн ажиллах вэ?</a>
              <a href="#reviews" onClick={() => setMenuOpen(false)}>Сэтгэгдэл</a>
            </nav>
          </div>
        )}
      </header>

      <main>
        <section className="mx-auto grid max-w-[1440px] gap-12 px-5 pb-16 pt-10 md:px-10 md:pt-16 lg:grid-cols-[1.1fr_0.9fr] lg:px-16 lg:pb-24 lg:pt-20">
          <div className="relative z-10">
            <div className="inline-flex items-center gap-2 rounded-full border border-black/15 bg-white/60 px-4 py-2 text-xs font-bold uppercase tracking-[0.12em]">
              <span className="size-2 rounded-full bg-[#70d44b]" />
              18,000+ бүтээгчийн сонголт
            </div>
            <h1 className="mt-7 max-w-4xl text-[clamp(3.6rem,8vw,7.8rem)] font-black leading-[0.84] tracking-[-0.075em]">
              СОШИАЛАА
              <span className="relative ml-[0.08em] inline-block text-[#6d4aff]">
                ӨСГӨ.
                <svg className="absolute -bottom-3 left-0 w-full text-[#d8ff3e]" viewBox="0 0 400 18" fill="none" aria-hidden="true">
                  <path d="M4 12C90 2 277 3 396 7" stroke="currentColor" strokeWidth="10" strokeLinecap="round" />
                </svg>
              </span>
            </h1>
            <p className="mt-10 max-w-xl text-lg leading-8 text-black/60 md:text-xl">
              Дагагч, лайк, үзэлт, шэйр, захиалагчаа найдвартай бөгөөд хурдан нэм. Үнээ шууд тооцоолж, хүргэлтээ бодитоор хянаарай.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <button onClick={scrollToServices} className="group flex cursor-pointer items-center justify-center gap-3 rounded-full bg-[#111111] px-7 py-4 font-bold text-white transition hover:bg-[#6d4aff]">
                Үйлчилгээ үзэх
                <Arrow className="size-5 transition-transform group-hover:translate-x-1" />
              </button>
              <div className="flex items-center justify-center gap-3 px-4 py-3 sm:justify-start">
                <div className="flex -space-x-2">
                  {["bg-[#ff8aa8]", "bg-[#ffd76d]", "bg-[#6fffe9]"].map((color, i) => (
                    <span key={color} className={`grid size-9 place-items-center rounded-full border-2 border-[#f5f3ee] ${color} text-[10px] font-black`}>
                      {["MK", "AJ", "LO"][i]}
                    </span>
                  ))}
                </div>
                <div>
                  <div className="flex text-[#f0a92e]"><Star /><Star /><Star /><Star /><Star /></div>
                  <p className="mt-0.5 text-xs font-semibold text-black/50">2,400+ үнэлгээнээс 4.9</p>
                </div>
              </div>
            </div>
          </div>

          <div className="relative min-h-[440px] lg:min-h-[560px]">
            <div className="absolute inset-0 rotate-3 rounded-[2.5rem] bg-[#d8ff3e]" />
            <div className="absolute inset-0 -rotate-2 overflow-hidden rounded-[2.5rem] bg-[#6d4aff] p-6 text-white shadow-[0_30px_80px_rgba(68,45,180,0.3)] md:p-10">
              <div className="flex items-center justify-between">
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-white/60">Өсөлтийн шууд үзүүлэлт</p>
                <span className="flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-xs font-bold">
                  <span className="size-2 animate-pulse rounded-full bg-[#d8ff3e]" /> Идэвхтэй
                </span>
              </div>
              <div className="mt-12">
                <p className="text-7xl font-black tracking-[-0.07em] md:text-8xl">+2.8M</p>
                <p className="mt-2 text-white/60">энэ сард хүргэсэн нийт оролцоо</p>
              </div>
              <div className="mt-12 flex h-32 items-end gap-2 md:h-40">
                {[35, 50, 42, 68, 58, 75, 66, 88, 80, 100].map((height, i) => (
                  <div key={i} className="flex-1 rounded-t-full bg-white/15" style={{ height: `${height}%` }}>
                    <div className="h-1.5 w-full rounded-full bg-[#d8ff3e]" />
                  </div>
                ))}
              </div>
              <div className="mt-8 grid grid-cols-3 gap-3 border-t border-white/15 pt-6">
                {[
                  ["47K+", "Захиалга"],
                  ["98.7%", "Тогтоц"],
                  ["24/7", "Тусламж"],
                ].map(([value, label]) => (
                  <div key={label}>
                    <p className="text-xl font-bold">{value}</p>
                    <p className="text-xs text-white/50">{label}</p>
                  </div>
                ))}
              </div>
              <span className="absolute -right-12 -top-12 size-36 rounded-full border-[28px] border-white/5" />
            </div>
            <div className="absolute -bottom-5 -left-3 rotate-3 rounded-2xl bg-white p-4 shadow-xl md:-left-10">
              <div className="flex items-center gap-3">
                <span className="grid size-10 place-items-center rounded-xl bg-[#ff5d8f] text-xs font-black">IG</span>
                <div>
                  <p className="text-sm font-bold text-[#111111]">Захиалга биеллээ</p>
                  <p className="text-xs text-black/45">+1,000 шинэ дагагч</p>
                </div>
                <span className="ml-2 grid size-7 place-items-center rounded-full bg-[#d8ff3e] text-black"><Check /></span>
              </div>
            </div>
          </div>
        </section>

        <GrowthCalculator onOrder={setSelected} />

        <section id="services" className="bg-[#111111] px-5 pb-20 pt-32 text-white md:px-10 md:pt-40 lg:px-16 lg:pb-28">
          <div className="mx-auto max-w-[1312px]">
            <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#d8ff3e]">Өсөлтөө сонго</p>
                <h2 className="mt-4 max-w-2xl text-4xl font-black leading-[0.95] tracking-[-0.055em] md:text-6xl">
                  Өсөхөд хэрэгтэй бүх зүйл.
                </h2>
              </div>
              <p className="max-w-sm leading-7 text-white/50">Платформ, багцаа сонгоод үзэгч, дагагч тань хэрхэн өсөхийг хараарай.</p>
            </div>

            <div className="mt-10 flex gap-2 overflow-x-auto pb-3 [scrollbar-width:none] md:mt-14">
              {platforms.map((platform) => (
                <button
                  key={platform}
                  onClick={() => setActivePlatform(platform)}
                  className={`shrink-0 cursor-pointer rounded-full border px-5 py-3 text-sm font-bold transition ${
                    activePlatform === platform
                      ? "border-[#d8ff3e] bg-[#d8ff3e] text-black"
                      : "border-white/15 text-white/60 hover:border-white/40 hover:text-white"
                  }`}
                >
                  {platformLabels[platform]}
                </button>
              ))}
            </div>

            <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {visibleServices.map((service) => (
                <ServiceCard key={`${service.platform}-${service.title}`} service={service} onSelect={setSelected} />
              ))}
            </div>
          </div>
        </section>

        <section id="how-it-works" className="mx-auto max-w-[1440px] px-5 py-20 md:px-10 lg:px-16 lg:py-28">
          <div className="grid gap-14 lg:grid-cols-[0.75fr_1.25fr]">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#6d4aff]">Маш энгийн</p>
              <h2 className="mt-4 text-5xl font-black leading-[0.95] tracking-[-0.06em] md:text-6xl">Гурван алхам.<br />Бодит үр дүн.</h2>
            </div>
            <div className="grid gap-4 md:grid-cols-3">
              {[
                ["01", "Сонгох", "Зорилгодоо тохирох платформ болон өсөлтийн үйлчилгээгээ сонгоно."],
                ["02", "Тохируулах", "Профайл болон хүссэн хэмжээгээ оруулна. Нууц үг огт хэрэггүй."],
                ["03", "Өсөх", "Бид хүргэлтийг эхлүүлнэ. Та үр дүнгээ бодитоор хянах боломжтой."],
              ].map(([number, title, copy]) => (
                <article key={number} className="rounded-[1.75rem] border border-black/10 bg-white p-6">
                  <span className="grid size-10 place-items-center rounded-full bg-[#d8ff3e] text-xs font-black">{number}</span>
                  <h3 className="mt-12 text-2xl font-bold">{title}</h3>
                  <p className="mt-3 text-sm leading-6 text-black/55">{copy}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="reviews" className="px-5 pb-20 md:px-10 lg:px-16 lg:pb-28">
          <div className="relative mx-auto max-w-[1312px] overflow-hidden rounded-[2.5rem] bg-[#d8ff3e] px-6 py-16 text-center md:px-12 md:py-20">
            <p className="text-xs font-bold uppercase tracking-[0.18em]">Таны үзэгчид хүлээж байна</p>
            <h2 className="mx-auto mt-5 max-w-4xl text-5xl font-black leading-[0.9] tracking-[-0.065em] md:text-7xl">
              Хүлээхээ боль.<br />Өсөж эхэл.
            </h2>
            <p className="mx-auto mt-6 max-w-xl text-black/60">Анхаарал татах бодит үзэгчдээ өсгөж буй мянга мянган бүтээгч, брэндтэй нэгдээрэй.</p>
            <button onClick={scrollToServices} className="group mt-8 inline-flex cursor-pointer items-center gap-3 rounded-full bg-[#111111] px-7 py-4 font-bold text-white transition hover:scale-105">
              Үзэгчдээ өсгөх <Arrow className="size-5 transition-transform group-hover:translate-x-1" />
            </button>
            <span className="absolute -left-14 -top-14 size-36 rounded-full border-[30px] border-black/5" />
            <span className="absolute -bottom-16 -right-10 size-48 rounded-full bg-[#6d4aff]" />
          </div>
        </section>
      </main>

      <footer className="border-t border-black/10 px-5 py-8 md:px-10 lg:px-16">
        <div className="mx-auto flex max-w-[1312px] flex-col items-center justify-between gap-5 text-sm text-black/45 md:flex-row">
          <a href="#" className="flex items-center gap-2 font-black text-[#111111]">
            <span className="grid size-7 place-items-center rounded-lg bg-[#111111] text-[10px] text-[#d8ff3e]">D</span>
            DAGALTSAY
          </a>
          <p>© 2025 DAGALTSAY. Амбицтай бүтээгчдэд зориулав.</p>
          <div className="flex gap-5"><a href="#">Нууцлал</a><a href="#">Үйлчилгээний нөхцөл</a><a href="#">Тусламж</a></div>
        </div>
      </footer>

      {selected && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-5 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Сонгосон үйлчилгээ">
          <div className="w-full max-w-md rounded-[2rem] bg-white p-7 shadow-2xl">
            <div className="flex items-start justify-between">
              <span className={`grid size-12 place-items-center rounded-2xl ${selected.accent} text-sm font-black`}>{selected.mark}</span>
              <button onClick={closeCheckout} className="grid size-10 cursor-pointer place-items-center rounded-full bg-black/5 text-xl" aria-label="Хаах">×</button>
            </div>

            {checkoutStep === "account" ? (
              <>
                <p className="mt-7 text-xs font-bold uppercase tracking-[0.16em] text-[#6d4aff]">Алхам 1 / 2 · {selected.platform}</p>
                <h2 className="mt-2 text-3xl font-black tracking-[-0.04em]">Өсгөх аккаунтаа оруулна уу</h2>
                <p className="mt-3 leading-7 text-black/55">
                  {selected.platform} аккаунтын нэр эсвэл профайлын линкийг оруулна уу. Бид танаас нууц үг хэзээ ч асуухгүй.
                </p>
                <label className="mt-6 block">
                  <span className="text-xs font-bold text-black/50">{selected.platform} нэр эсвэл линк</span>
                  <input
                    autoFocus
                    value={targetAccount}
                    onChange={(event) => setTargetAccount(event.target.value)}
                    onKeyDown={(event) => event.key === "Enter" && openPayment()}
                    placeholder={selected.platform === "YouTube" ? "youtube.com/@сувгийн-нэр" : "@аккаунтын_нэр"}
                    className="mt-2 w-full rounded-2xl border border-black/10 bg-[#f5f3ee] px-4 py-4 font-semibold outline-none transition placeholder:text-black/25 focus:border-[#6d4aff] focus:ring-4 focus:ring-[#6d4aff]/10"
                  />
                </label>
                <div className="mt-5 rounded-2xl bg-[#f5f3ee] p-5">
                  <div className="flex justify-between text-sm"><span>Багц</span><strong>{selected.unit}</strong></div>
                  <div className="mt-3 flex justify-between border-t border-black/10 pt-3 text-sm"><span>Нийт үнэ</span><strong>{formatMnt(selected.price)}</strong></div>
                </div>
                <button
                  onClick={openPayment}
                  disabled={!targetAccount.trim()}
                  className="mt-5 flex w-full cursor-pointer items-center justify-center gap-2 rounded-full bg-[#111111] px-6 py-4 font-bold text-white transition hover:bg-[#6d4aff] disabled:cursor-not-allowed disabled:opacity-30"
                >
                  Төлбөр төлөх <Arrow className="size-5" />
                </button>
              </>
            ) : (
              <>
                <p className="mt-7 text-xs font-bold uppercase tracking-[0.16em] text-[#6d4aff]">Алхам 2 / 2 · Хаан банк</p>
                <h2 className="mt-2 text-3xl font-black tracking-[-0.04em]">Төлбөрийн мэдээлэл</h2>
                <p className="mt-3 text-sm leading-6 text-black/55">
                  Доорх дансанд <strong className="text-black">{formatMnt(selected.price)}</strong>-ийн шилжүүлэг хийнэ үү.
                </p>

                <div className="mt-6 overflow-hidden rounded-2xl border border-black/10">
                  <div className="flex items-center justify-between p-4">
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-black/40">Хаан банкны данс</p>
                      <p className="mt-1 font-black tracking-wide">070005005114553315</p>
                    </div>
                    <button onClick={() => copyPaymentValue("070005005114553315", "account")} className="cursor-pointer rounded-xl bg-black/5 px-3 py-2 text-xs font-bold hover:bg-[#d8ff3e]">
                      {copied === "account" ? "Хууллаа" : "Хуулах"}
                    </button>
                  </div>
                  <div className="border-t border-black/10 p-4">
                    <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-black/40">Хүлээн авагч</p>
                    <p className="mt-1 font-black">GALINDEV</p>
                  </div>
                  <div className="flex items-center justify-between border-t border-black/10 bg-[#d8ff3e] p-4">
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-black/50">Гүйлгээний утга</p>
                      <p className="mt-1 text-2xl font-black tracking-[0.18em]">{paymentCode}</p>
                    </div>
                    <button onClick={() => copyPaymentValue(paymentCode, "code")} className="cursor-pointer rounded-xl bg-black px-3 py-2 text-xs font-bold text-white">
                      {copied === "code" ? "Хууллаа" : "Хуулах"}
                    </button>
                  </div>
                </div>

                <div className="mt-5 flex items-start gap-3 rounded-2xl bg-[#f5f3ee] p-4 text-xs leading-5 text-black/55">
                  <span className="grid size-6 shrink-0 place-items-center rounded-full bg-[#6d4aff] font-black text-white">!</span>
                  Гүйлгээний утгад зөвхөн дээрх 5 оронтой кодыг бичнэ үү. Төлбөрийн баримтаа хадгалаарай.
                </div>
                <button onClick={closeCheckout} className="mt-5 w-full cursor-pointer rounded-full bg-[#111111] px-6 py-4 font-bold text-white transition hover:bg-[#6d4aff]">
                  Ойлголоо, хаах
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
